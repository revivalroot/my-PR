package com.cookandroid.w12;

import android.os.Bundle;
import android.os.SystemClock;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // ── 위젯 ──────────────────────────────────────────────────────
    private Chronometer chronometerStudy;
    private ProgressBar progressStudy;
    private SeekBar     seekBarGoal;
    private Button      btnStart, btnStop, btnReset;
    private TextView    textGoal, textProgress, textStatus;

    // ── 상태 변수 ─────────────────────────────────────────────────
    private boolean isRunning = false;   // 실행 중 여부
    private long pauseOffset = 0;       // 정지 시 경과 시간 저장

    // SeekBar 6단계 → 목표 시간(분)
    private final int[] GOAL_MINUTES = {10, 20, 30, 40, 50, 60};
    private int goalMinutes = 10;   // 현재 선택된 목표 시간(분)

    // 실습용 환산 : 1분 = 5초  (10분 → 50초 안에 목표 달성)
    private static final int SECONDS_PER_MINUTE = 5;
    private long goalMillis = 10 * SECONDS_PER_MINUTE * 1000L;  // 목표 시간(ms)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 위젯 연결
        chronometerStudy = findViewById(R.id.chronometerStudy);
        progressStudy    = findViewById(R.id.progressStudy);
        seekBarGoal      = findViewById(R.id.seekBarGoal);
        btnStart         = findViewById(R.id.btnStart);
        btnStop          = findViewById(R.id.btnStop);
        btnReset         = findViewById(R.id.btnReset);
        textGoal         = findViewById(R.id.textGoal);
        textProgress     = findViewById(R.id.textProgress);
        textStatus       = findViewById(R.id.textStatus);

        // 초기 화면
        chronometerStudy.setText("학습 시간 : 00:00");
        progressStudy.setProgress(0);
        textProgress.setText("진행률 : 0%");
        textStatus.setText("초기화되었습니다. 시작 버튼을 누르세요.");
        updateGoalText();

        // SeekBar : 목표 학습 시간 선택
        seekBarGoal.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                // progress(0~5) → GOAL_MINUTES 배열 인덱스
                goalMinutes = GOAL_MINUTES[progress];
                goalMillis  = (long) goalMinutes * SECONDS_PER_MINUTE * 1000L;
                updateGoalText();

                if (!isRunning) {
                    progressStudy.setProgress(0);
                    textProgress.setText("진행률 : 0%");
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb)  {}
        });

        // 시작 버튼
        btnStart.setOnClickListener(v -> {
            if (!isRunning) {
                // 정지했다가 다시 시작하면 이어서 진행
                chronometerStudy.setBase(SystemClock.elapsedRealtime() - pauseOffset);
                chronometerStudy.start();
                isRunning = true;
                textStatus.setText("학습 중입니다.");
            }
        });

        // 정지 버튼
        btnStop.setOnClickListener(v -> {
            if (isRunning) {
                // 경과 시간 저장 후 정지
                pauseOffset = SystemClock.elapsedRealtime() - chronometerStudy.getBase();
                chronometerStudy.stop();
                isRunning = false;
                textStatus.setText("학습이 일시정지되었습니다.");
            }
        });

        // 초기화 버튼
        btnReset.setOnClickListener(v -> {
            chronometerStudy.stop();
            chronometerStudy.setBase(SystemClock.elapsedRealtime());
            chronometerStudy.setText("학습 시간 : 00:00");
            pauseOffset = 0;
            isRunning   = false;
            progressStudy.setProgress(0);
            textProgress.setText("진행률 : 0%");
            textStatus.setText("초기화되었습니다. 시작 버튼을 누르세요.");
        });

        // OnChronometerTickListener
        chronometerStudy.setOnChronometerTickListener(
                new Chronometer.OnChronometerTickListener() {
                    @Override
                    public void onChronometerTick(Chronometer chronometer) {

                        // 경과 시간 계산
                        long elapsedMillis =
                                SystemClock.elapsedRealtime() - chronometerStudy.getBase();

                        // 진행률 계산
                        int progress = (int) ((elapsedMillis * 100) / goalMillis);
                        if (progress > 100) progress = 100;

                        progressStudy.setProgress(progress);
                        textProgress.setText("진행률 : " + progress + "%");

                        // 학습 시간 : MM:SS" 형식으로 표시
                        int totalSeconds = (int) (elapsedMillis / 1000);
                        int minutes = totalSeconds / 60;
                        int seconds = totalSeconds % 60;
                        chronometerStudy.setText(String.format(Locale.getDefault(),
                                "학습 시간 : %02d:%02d", minutes, seconds));

                        // 목표 시간 도달 시 정지 + 메시지 출력
                        if (elapsedMillis >= goalMillis) {
                            chronometerStudy.stop();
                            isRunning = false;
                            progressStudy.setProgress(100);
                            textProgress.setText("진행률 : 100%");
                            textStatus.setText("목표 학습 시간을 달성했습니다!");
                        }
                    }
                });
    }

    // 목표 학습 시간 안내 텍스트 갱신
    private void updateGoalText() {
        int goalSec = goalMinutes * SECONDS_PER_MINUTE;   // 실습용 환산 초
        textGoal.setText(String.format(Locale.getDefault(),
                "목표 학습 시간 : %d분 (실습용 %d초)", goalMinutes, goalSec));
    }
}