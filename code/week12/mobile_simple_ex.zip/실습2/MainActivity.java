package com.cookandroid.ex_2;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.MultiAutoCompleteTextView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // 위젯
    private AutoCompleteTextView autoCity;
    private MultiAutoCompleteTextView autoItems;
    private DatePicker datePicker;
    private RatingBar ratingBar;
    private Button btnSave, btnReset;
    private TextView textResult;

    // 자동완성 데이터
    private final String[] cities = {
            "서울", "부산", "제주", "강릉", "전주", "여수", "경주", "속초"
    };
    private final String[] items = {
            "충전기", "보조배터리", "세면도구", "우산", "카메라", "수건", "이어폰", "상비약"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 위젯 연결
        autoCity   = findViewById(R.id.autoCity);
        autoItems  = findViewById(R.id.autoItems);
        datePicker = findViewById(R.id.datePicker);
        ratingBar  = findViewById(R.id.ratingBar);
        btnSave    = findViewById(R.id.btnSave);
        btnReset   = findViewById(R.id.btnReset);
        textResult = findViewById(R.id.textResult);

        // 여행지 자동완성 설정
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, cities);
        autoCity.setAdapter(cityAdapter);
        autoCity.setThreshold(1);   // 1글자 입력 시 자동완성

        // 준비물 자동완성 설정 (쉼표 단위)
        ArrayAdapter<String> itemAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, items);
        autoItems.setAdapter(itemAdapter);
        // 쉼표(,)를 구분자로 사용 → 여러 항목 자동완성 가능
        autoItems.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        autoItems.setThreshold(1);

        // 계획 저장 버튼
        btnSave.setOnClickListener(v -> {
            String city   = autoCity.getText().toString().trim();
            String item   = autoItems.getText().toString().trim();
            float  rating = ratingBar.getRating();

            // 날짜 가져오기
            int year  = datePicker.getYear();
            int month = datePicker.getMonth() + 1;   // 0부터 시작하므로 +1
            int day   = datePicker.getDayOfMonth();

            // 입력 검증
            if (city.isEmpty()) {
                Toast.makeText(this, "여행지를 입력하세요.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // 결과 문자열 생성
            StringBuilder sb = new StringBuilder();
            sb.append("여행지 : ").append(city).append("\n");
            sb.append(String.format(Locale.getDefault(),
                    "여행 날짜 : %d년 %d월 %d일\n", year, month, day));
            sb.append("준비물 : ")
                    .append(item.isEmpty() ? "없음" : item).append("\n");
            sb.append(String.format(Locale.getDefault(),
                    "기대도 : %.1f점", rating));

            // 기대도 4점 이상이면 추가 문구
            if (rating >= 4.0f) {
                sb.append("\n\n기대되는 여행입니다!");
            }

            textResult.setText(sb.toString());

            // 저장 완료 Toast
            Toast.makeText(this, "여행 계획이 저장되었습니다.",
                    Toast.LENGTH_SHORT).show();
        });

        // 초기화 버튼
        btnReset.setOnClickListener(v -> {
            autoCity.setText("");
            autoItems.setText("");
            ratingBar.setRating(3);
            textResult.setText("아직 저장된 여행 계획이 없습니다.");
            Toast.makeText(this, "초기화되었습니다.",
                    Toast.LENGTH_SHORT).show();
        });
    }
}