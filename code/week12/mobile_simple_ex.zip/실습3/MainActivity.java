package com.cookandroid.ex_3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ViewFlipper;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // 위젯
    private ViewFlipper viewFlipperGuide;
    private SeekBar     seekBarSpeed;
    private ProgressBar progressGuide;
    private Button      btnPrev, btnNext, btnAutoStart, btnAutoStop;
    private TextView    textPage, textSpeed, textStatus;

    // 전체 슬라이드 개수
    private static final int TOTAL = 4;

    // 자동 전환 속도(초) — SeekBar 0단계 기본 → 실제 기본 2초 (progress=1)
    private int flipSecond = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 위젯 연결
        viewFlipperGuide = findViewById(R.id.viewFlipperGuide);
        seekBarSpeed     = findViewById(R.id.seekBarSpeed);
        progressGuide    = findViewById(R.id.progressGuide);
        btnPrev          = findViewById(R.id.btnPrev);
        btnNext          = findViewById(R.id.btnNext);
        btnAutoStart     = findViewById(R.id.btnAutoStart);
        btnAutoStop      = findViewById(R.id.btnAutoStop);
        textPage         = findViewById(R.id.textPage);
        textSpeed        = findViewById(R.id.textSpeed);
        textStatus       = findViewById(R.id.textStatus);

        // 초기 상태 표시
        updatePageInfo();

        // 다음 버튼 : showNext()
        btnNext.setOnClickListener(v -> {
            viewFlipperGuide.showNext();
            updatePageInfo();
            textStatus.setText("다음 안내 화면으로 이동했습니다.");
        });

        // 이전 버튼 : showPrevious()
        btnPrev.setOnClickListener(v -> {
            viewFlipperGuide.showPrevious();
            updatePageInfo();
            textStatus.setText("이전 안내 화면으로 이동했습니다.");
        });

        // 자동 시작 버튼 : startFlipping()
        btnAutoStart.setOnClickListener(v -> {
            viewFlipperGuide.setFlipInterval(flipSecond * 1000);
            viewFlipperGuide.startFlipping();
            textStatus.setText("자동 전환을 시작했습니다. (" + flipSecond + "초 간격)");
        });

        // 자동 정지 버튼 : stopFlipping()
        btnAutoStop.setOnClickListener(v -> {
            viewFlipperGuide.stopFlipping();
            updatePageInfo();
            textStatus.setText("자동 전환을 정지했습니다.");
        });

        // SeekBar : 자동 전환 속도 (0~4단계 → 1~5초)
        seekBarSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                // 0단계=1초, 1단계=2초, 2단계=3초, 3단계=4초, 4단계=5초
                flipSecond = progress + 1;
                textSpeed.setText("자동 전환 속도 : " + flipSecond + "초");

                // 자동 전환 중이면 새 간격으로 즉시 반영
                if (viewFlipperGuide.isFlipping()) {
                    viewFlipperGuide.setFlipInterval(flipSecond * 1000);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb)  {}
        });
    }

    // 현재 화면 번호 / ProgressBar 갱신
    private void updatePageInfo() {
        int current = viewFlipperGuide.getDisplayedChild() + 1;  // 0부터 시작 → +1

        textPage.setText(String.format(Locale.getDefault(),
                "현재 화면 : %d / %d", current, TOTAL));

        progressGuide.setProgress(current);
    }

    // 앱 종료 시 자동 전환 정지
    @Override
    protected void onPause() {
        super.onPause();
        if (viewFlipperGuide.isFlipping()) {
            viewFlipperGuide.stopFlipping();
        }
    }
}